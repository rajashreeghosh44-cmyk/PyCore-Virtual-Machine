import unittest
from novavm.vm import VirtualMachine, parse_program, VMError

class NovaVMTests(unittest.TestCase):
    def execute(self, source):
        vm = VirtualMachine(parse_program(source))
        vm.run()
        return vm

    def test_arithmetic(self):
        vm = self.execute("PUSH 4\nPUSH 3\nADD\nPRINT\nHALT")
        self.assertEqual(vm.output, ["7"])

    def test_variables(self):
        vm = self.execute("PUSH 9\nSTORE x\nLOAD x\nPRINT")
        self.assertEqual(vm.output, ["9"])

    def test_loop(self):
        vm = self.execute("PUSH 2\nSTORE n\nagain:\nLOAD n\nPUSH 0\nGT\nJZ end\nLOAD n\nPRINT\nLOAD n\nPUSH 1\nSUB\nSTORE n\nJUMP again\nend:\nHALT")
        self.assertEqual(vm.output, ["2", "1"])

    def test_division_by_zero(self):
        vm = VirtualMachine(parse_program("PUSH 1\nPUSH 0\nDIV"))
        with self.assertRaises(VMError): vm.run()

    def test_reset(self):
        vm = self.execute("PUSH 8\nPRINT")
        vm.reset()
        self.assertEqual(vm.steps, 0)
        self.assertEqual(vm.stack, [])
        self.assertEqual(vm.output, [])

if __name__ == "__main__":
    unittest.main()
