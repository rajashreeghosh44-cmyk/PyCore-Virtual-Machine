"""Command-line runner for NovaVM."""
import argparse
from pathlib import Path
from .vm import VirtualMachine, parse_program, VMError

def main():
    parser = argparse.ArgumentParser(description="Run a NovaVM assembly program")
    parser.add_argument("file", help="Path to a .nvm program")
    parser.add_argument("--trace", action="store_true", help="Print instruction trace")
    args = parser.parse_args()
    try:
        source = Path(args.file).read_text(encoding="utf-8")
        vm = VirtualMachine(parse_program(source))
        result = vm.run()
        if result: print(result)
        if args.trace:
            print("\nTRACE")
            print("\n".join(vm.trace))
        print("\nSUMMARY")
        print(vm.summary())
    except (OSError, VMError) as exc:
        print(f"NovaVM error: {exc}")
        raise SystemExit(1)

if __name__ == "__main__":
    main()
