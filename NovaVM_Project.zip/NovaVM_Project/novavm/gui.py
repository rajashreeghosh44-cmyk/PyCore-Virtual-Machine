"""Simple Tkinter interface for NovaVM."""
import tkinter as tk
from tkinter import filedialog, messagebox
from .vm import VirtualMachine, parse_program, VMError

class NovaVMApp:
    def __init__(self, root):
        self.root = root
        root.title("NovaVM - Bytecode Learning Studio")
        root.geometry("1050x720")
        self.vm = None
        tk.Label(root, text="NovaVM Program (.nvm assembly)", font=("Arial", 12, "bold")).pack(anchor="w", padx=10, pady=(10,0))
        self.editor = tk.Text(root, height=17, font=("Consolas", 11))
        self.editor.pack(fill="both", expand=True, padx=10, pady=5)
        self.editor.insert("1.0", "PUSH 12\nPUSH 5\nMUL\nSTORE answer\nLOAD answer\nPRINT\nHALT\n")
        bar = tk.Frame(root); bar.pack(fill="x", padx=10)
        for label, command in [("Load", self.load), ("Start / Run", self.run), ("Step", self.step), ("Reset", self.reset)]:
            tk.Button(bar, text=label, command=command, width=14).pack(side="left", padx=4, pady=4)
        self.status = tk.Label(root, text="Ready", anchor="w"); self.status.pack(fill="x", padx=10)
        panes = tk.Frame(root); panes.pack(fill="both", expand=True, padx=10, pady=5)
        self.out = self._panel(panes, "Output")
        self.stack = self._panel(panes, "Stack and Variables")
        self.trace = self._panel(panes, "Execution Trace")
        for widget in (self.out, self.stack, self.trace):
            widget.master.pack_configure(side="left", fill="both", expand=True, padx=3)

    def _panel(self, parent, title):
        frame = tk.LabelFrame(parent, text=title)
        text = tk.Text(frame, height=12, width=35, state="disabled", font=("Consolas", 9))
        text.pack(fill="both", expand=True)
        frame.pack(side="left", fill="both", expand=True)
        return text

    def _show(self, widget, value):
        widget.configure(state="normal"); widget.delete("1.0", "end")
        widget.insert("end", str(value)); widget.configure(state="disabled")

    def _prepare(self):
        self.vm = VirtualMachine(parse_program(self.editor.get("1.0", "end")))
        self._refresh()

    def _refresh(self):
        if not self.vm: return
        self._show(self.out, "\n".join(self.vm.output))
        self._show(self.stack, f"Stack: {self.vm.stack}\n\nVariables: {self.vm.variables}\n\nSteps: {self.vm.steps}\nPC: {self.vm.pc}")
        self._show(self.trace, "\n".join(self.vm.trace))
        self.status.config(text="Finished" if self.vm.halted else "Ready / Paused")

    def load(self):
        path = filedialog.askopenfilename(filetypes=[("NovaVM programs", "*.nvm"), ("All files", "*.*")])
        if path:
            try:
                with open(path, encoding="utf-8") as f: self.editor.delete("1.0", "end"); self.editor.insert("1.0", f.read())
                self._prepare()
            except OSError as exc: messagebox.showerror("Load error", str(exc))

    def run(self):
        try:
            if self.vm is None: self._prepare()
            self.vm.run(); self._refresh()
        except VMError as exc: self.status.config(text=f"Error: {exc}"); messagebox.showerror("NovaVM error", str(exc))

    def step(self):
        try:
            if self.vm is None: self._prepare()
            self.vm.step(); self._refresh()
        except VMError as exc: self.status.config(text=f"Error: {exc}"); messagebox.showerror("NovaVM error", str(exc))

    def reset(self):
        try:
            self._prepare()
            self.status.config(text="Execution state reset")
        except VMError as exc: messagebox.showerror("Program error", str(exc))

def main():
    root = tk.Tk()
    NovaVMApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
