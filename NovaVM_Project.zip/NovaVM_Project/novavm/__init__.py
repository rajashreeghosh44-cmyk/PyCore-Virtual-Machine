"""NovaVM: a small educational stack-based virtual machine."""
from .vm import VirtualMachine, VMError, parse_program

__all__ = ["VirtualMachine", "VMError", "parse_program"]
