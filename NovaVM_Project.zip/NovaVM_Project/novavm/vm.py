"""Core of NovaVM: a beginner-friendly stack-based virtual machine."""
from dataclasses import dataclass, field
from typing import Any

class VMError(Exception):
    """Raised when a NovaVM program contains an invalid instruction or runtime error."""

@dataclass
class Instruction:
    opcode: str
    argument: Any = None
    line: int = 0

@dataclass
class VirtualMachine:
    instructions: list[Instruction]
    stack: list[Any] = field(default_factory=list)
    variables: dict[str, Any] = field(default_factory=dict)
    output: list[str] = field(default_factory=list)
    trace: list[str] = field(default_factory=list)
    pc: int = 0
    steps: int = 0
    halted: bool = False

    def reset(self):
        """Reset stack, variables, output, trace and program counter."""
        self.stack.clear()
        self.variables.clear()
        self.output.clear()
        self.trace.clear()
        self.pc = 0
        self.steps = 0
        self.halted = False

    def _pop(self):
        if not self.stack:
            raise VMError(f"Stack underflow at instruction {self.pc + 1}")
        return self.stack.pop()

    def _binary(self, operation):
        right = self._pop()
        left = self._pop()
        try:
            self.stack.append(operation(left, right))
        except ZeroDivisionError:
            raise VMError(f"Division by zero at instruction {self.pc + 1}")
        except (TypeError, ValueError) as exc:
            raise VMError(f"Invalid operands at instruction {self.pc + 1}: {exc}")

    def step(self):
        """Execute one instruction. Returns False when execution is finished."""
        if self.halted or self.pc >= len(self.instructions):
            self.halted = True
            return False

        inst = self.instructions[self.pc]
        old_pc = self.pc
        self.pc += 1
        op, arg = inst.opcode, inst.argument
        self.steps += 1

        try:
            if op == "PUSH":
                self.stack.append(arg)
            elif op == "LOAD":
                if arg not in self.variables:
                    raise VMError(f"Undefined variable '{arg}' at line {inst.line}")
                self.stack.append(self.variables[arg])
            elif op == "STORE":
                self.variables[arg] = self._pop()
            elif op == "ADD":
                self._binary(lambda a, b: a + b)
            elif op == "SUB":
                self._binary(lambda a, b: a - b)
            elif op == "MUL":
                self._binary(lambda a, b: a * b)
            elif op == "DIV":
                self._binary(lambda a, b: a / b)
            elif op == "MOD":
                self._binary(lambda a, b: a % b)
            elif op == "NEG":
                self.stack.append(-self._pop())
            elif op == "DUP":
                if not self.stack: raise VMError("Cannot DUP an empty stack")
                self.stack.append(self.stack[-1])
            elif op == "SWAP":
                if len(self.stack) < 2: raise VMError("SWAP requires two stack values")
                self.stack[-1], self.stack[-2] = self.stack[-2], self.stack[-1]
            elif op == "POP":
                self._pop()
            elif op == "PRINT":
                self.output.append(str(self._pop()))
            elif op == "EQ":
                self._binary(lambda a, b: a == b)
            elif op == "GT":
                self._binary(lambda a, b: a > b)
            elif op == "LT":
                self._binary(lambda a, b: a < b)
            elif op == "JUMP":
                self.pc = arg
            elif op == "JZ":
                if not self._pop():
                    self.pc = arg
            elif op == "HALT":
                self.halted = True
            else:
                raise VMError(f"Unknown instruction '{op}' at line {inst.line}")
        except VMError:
            raise
        except Exception as exc:
            raise VMError(f"{op} failed at line {inst.line}: {exc}")

        self.trace.append(
            f"step {self.steps:03d} | pc {old_pc:03d} | {op}"
            + (f" {arg}" if arg is not None else "")
            + f" | stack={self.stack!r}"
        )
        if self.pc >= len(self.instructions):
            self.halted = True
        return not self.halted

    def run(self, max_steps=10000):
        """Run until HALT/end; max_steps protects against accidental infinite loops."""
        while not self.halted and self.pc < len(self.instructions):
            if self.steps >= max_steps:
                raise VMError(f"Execution stopped after {max_steps} steps (possible infinite loop)")
            self.step()
        self.halted = True
        return "\\n".join(self.output)

    def summary(self):
        return {
            "instructions_executed": self.steps,
            "output_lines": len(self.output),
            "variables": dict(self.variables),
            "final_stack": list(self.stack),
            "halted": self.halted,
        }

def parse_program(source: str) -> list[Instruction]:
    """Parse NovaVM assembly text and resolve labels into instruction indexes."""
    raw = []
    labels = {}
    for line_no, original in enumerate(source.splitlines(), 1):
        line = original.split("#", 1)[0].strip()
        if not line:
            continue
        if line.endswith(":"):
            label = line[:-1].strip()
            if not label or label in labels:
                raise VMError(f"Invalid or duplicate label on line {line_no}")
            labels[label] = len(raw)
            continue
        parts = line.split(maxsplit=1)
        op = parts[0].upper()
        arg = parts[1].strip() if len(parts) > 1 else None
        raw.append((op, arg, line_no))

    instructions = []
    for op, arg, line_no in raw:
        if op == "PUSH":
            if arg is None: raise VMError(f"PUSH needs a value on line {line_no}")
            if arg.lower() in ("true", "false"):
                value = arg.lower() == "true"
            else:
                try: value = int(arg)
                except ValueError:
                    try: value = float(arg)
                    except ValueError:
                        if len(arg) >= 2 and arg[0] == arg[-1] and arg[0] in ("'", '"'):
                            value = arg[1:-1]
                        else:
                            raise VMError(f"PUSH accepts a number, true/false, or quoted text (line {line_no})")
            arg = value
        elif op in ("LOAD", "STORE"):
            if not arg: raise VMError(f"{op} needs a variable name on line {line_no}")
        elif op in ("JUMP", "JZ"):
            if arg not in labels: raise VMError(f"Unknown label '{arg}' on line {line_no}")
            arg = labels[arg]
        elif op in ("ADD","SUB","MUL","DIV","MOD","NEG","DUP","SWAP","POP","PRINT","EQ","GT","LT","HALT"):
            if arg is not None: raise VMError(f"{op} takes no argument (line {line_no})")
        else:
            raise VMError(f"Unknown instruction '{op}' on line {line_no}")
        instructions.append(Instruction(op, arg, line_no))
    return instructions
