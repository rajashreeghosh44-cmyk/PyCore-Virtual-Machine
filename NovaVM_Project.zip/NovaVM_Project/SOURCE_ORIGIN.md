# Source origin and modification record

Reference repository supplied for this project:
https://github.com/DeveloperJarvis/python_bytecode_interpreter

The reference repository describes a minimal VM that parses `.pyc` files, decodes a subset of CPython bytecode and executes it with a stack-based execution model.

Important distinction: this delivered NovaVM folder is an independently written educational implementation inspired by those broad VM concepts. It is not a clone, fork, or patch of the DeveloperJarvis source. The development environment could not fetch GitHub's source archive, so no claim is made that the reference repository's files were modified. This distinction is included to avoid misrepresenting the source history in an academic submission.

NovaVM's own additions are documented in README.md and the project report.
