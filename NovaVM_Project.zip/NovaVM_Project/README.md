# NovaVM — Bytecode Learning Studio

NovaVM is a small educational, stack-based virtual machine written in Python. It is inspired by the learning goals and high-level architecture of the public [DeveloperJarvis Python Bytecode Interpreter](https://github.com/DeveloperJarvis/python_bytecode_interpreter), but this package is a separate implementation with its own instruction set. It does **not** contain copied files from that repository and does not claim to be a modification of its source.

## Requirements
- Python 3.9 or newer
- Tkinter (usually included with standard Python installers)
- No third-party Python packages required

## Run
From the project folder:

```bash
python -m novavm.cli examples/arithmetic.nvm --trace
```

Run the GUI:

```bash
python -m novavm.gui
```

Run tests:

```bash
python -m unittest discover -s tests -v
```

## NovaVM instruction set

| Instruction | Meaning |
|---|---|
| `PUSH value` | Push a number, true/false, or quoted string |
| `LOAD name` | Push a stored variable |
| `STORE name` | Save top stack value into a variable |
| `ADD`, `SUB`, `MUL`, `DIV`, `MOD` | Arithmetic |
| `NEG` | Negate top value |
| `EQ`, `GT`, `LT` | Compare two values |
| `DUP`, `SWAP`, `POP` | Stack manipulation |
| `PRINT` | Pop and display top value |
| `JUMP label` | Unconditional jump |
| `JZ label` | Pop condition; jump if false/zero |
| `HALT` | Stop execution |

Labels are written as `label_name:`. Use `#` for comments.

## Added learning and debugging features
1. Step-by-step execution (`Step` button).
2. Instruction trace with program-counter and stack snapshots.
3. Instruction execution counter.
4. Stack and variable inspector.
5. Friendly errors for invalid instructions, missing variables, stack underflow and division by zero.
6. Reset execution state.
7. Labels and conditional/unconditional jumps for loops and branches.

## Project provenance and academic honesty
The external repository is a reference for the general subject of bytecode interpretation and stack-based VM design. NovaVM is an independently written educational VM; it does not parse CPython `.pyc` files and is not a source-level fork or modification of DeveloperJarvis's repository. If your professor specifically requires modifying that exact repository, clone/download it separately and make your changes directly in that codebase before claiming it as the modified original.

## Limitations
NovaVM runs its own small assembly-like instruction language. It is not a full Python interpreter and cannot execute arbitrary `.py` or `.pyc` files. This design keeps the execution engine understandable and suitable for demonstrating VM concepts.
