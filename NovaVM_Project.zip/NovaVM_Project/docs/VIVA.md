# Viva Preparation — NovaVM

1. **What is a virtual machine?** A software-based execution environment that runs instructions using defined rules.
2. **What is bytecode?** A lower-level instruction representation produced from source code.
3. **What is a stack?** A last-in, first-out data structure.
4. **What is a stack-based VM?** A VM that uses a stack to hold operands and intermediate values.
5. **What is the program counter?** The index of the next instruction to execute.
6. **What is an instruction?** One operation such as PUSH, ADD or PRINT.
7. **What does PUSH do?** Adds a value to the top of the stack.
8. **What does POP do?** Removes the top stack value.
9. **What does STORE do?** Removes a stack value and saves it in a named variable.
10. **What does LOAD do?** Pushes a stored variable value onto the stack.
11. **Why is the stack LIFO?** The most recently pushed value is the first one removed.
12. **What is an execution trace?** A record of instructions executed and their state.
13. **Why count instructions?** To measure the amount of VM work and support debugging.
14. **What is stack underflow?** Trying to remove a value when the stack is empty.
15. **How does NovaVM handle division by zero?** It raises a readable VMError.
16. **What is a label?** A named location in a program used as a jump destination.
17. **What does JUMP do?** Changes the program counter to a label's instruction.
18. **What does JZ do?** Pops a condition and jumps when it is false or zero.
19. **What does HALT do?** Stops VM execution.
20. **What is step execution?** Executing one instruction at a time.
21. **Why is reset useful?** It clears the previous run's state so a program can be run again.
22. **What is the role of the parser?** It converts readable instruction lines into Instruction objects and resolves labels.
23. **What is the role of the VM loop?** It repeatedly fetches and executes instructions.
24. **Is NovaVM a complete Python interpreter?** No. It executes its own small educational instruction set.
25. **What is the difference from the reference project?** The reference focuses on a subset of CPython `.pyc` bytecode; NovaVM uses its own readable assembly-like instructions and adds a GUI, stepping, trace, statistics and reset.
26. **What are the limitations?** It does not support arbitrary Python source, CPython `.pyc`, classes, exceptions in user programs or concurrency.
27. **What can be added in future?** Function-call frames, more data types, source-to-bytecode compilation and richer breakpoints.
28. **Why use Python?** It is readable, widely available and suitable for teaching interpreter concepts.
29. **What is a runtime error?** An error detected while instructions are executing.
30. **What is the project objective?** To demonstrate how a stack-based virtual machine fetches, decodes and executes instructions.
